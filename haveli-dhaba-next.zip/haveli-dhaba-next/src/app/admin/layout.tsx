import Link from "next/link";
import { requireAdmin } from "@/lib/supabase/server";
export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const a = await requireAdmin();
  if (!a) return <>{children}</>; // login page; protected pages redirect themselves
  return (<div style={{ background: "#1a0709", color: "#F7F0E3", minHeight: "100vh", fontFamily: "Inter,sans-serif" }}>
    <nav style={{ display: "flex", flexWrap: "wrap", gap: 20, padding: 16, borderBottom: "1px solid #C6A15B55" }}><b style={{ color: "#C6A15B" }}>Haveli Dhaba Admin</b>
      <Link href="/admin/bookings">Bookings</Link><Link href="/admin/menu">Menu</Link><Link href="/admin/gallery">Gallery</Link><Link href="/admin/settings">Settings</Link><Link href="/" target="_blank">View site</Link></nav><main style={{ padding: 20 }}>{children}</main></div>);
}

"use client";
import { useEffect, useMemo, useRef, useState } from "react";
import BookingForm from "./BookingForm";
import type { GalleryImg, MenuCat, Settings } from "@/data/defaults";

const MAPS = "https://www.google.com/maps/search/?api=1&query=Haveli+Dhaba+Ulda+Jharkhand+832304";
const NAV: [string, string][] = [["#home", "Home"], ["#about", "About Us"], ["#menu", "Our Menu"], ["#gallery", "Gallery"], ["#family", "Family & Kids"], ["#venue", "Book Our Venue"], ["#contact", "Contact"]];

function Menu({ menu }: { menu: MenuCat[] }) {
  const [cat, setCat] = useState(0); const [q, setQ] = useState("");
  const list = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return (menu[cat]?.items ?? []).map((i) => ({ ...i, cat: "" }));
    return menu.flatMap((c) => c.items.filter((i) => i.name.toLowerCase().includes(s)).map((i) => ({ ...i, cat: c.name })));
  }, [menu, cat, q]);
  return (<>
    <div className="tools"><input type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search dishes, e.g. paneer, biryani…" aria-label="Search menu" /></div>
    <div className="tabs" role="tablist" aria-label="Menu categories">{menu.map((c, i) => <button key={c.name} className="tab" role="tab" aria-selected={!q && i === cat} onClick={() => { setCat(i); setQ(""); }}>{c.name}</button>)}</div>
    <div className="items" aria-live="polite">{list.length ? list.map((i, k) => (<div className="it" key={i.name + k}><span>{i.name}</span>{q ? <small>{i.cat.toUpperCase()}</small> : i.price != null && <small className="pr">₹{i.price}</small>}</div>)) : <div className="empty">No dishes found. Try another word.</div>}</div>
  </>);
}

function Gallery({ images }: { images: GalleryImg[] }) {
  const [cur, setCur] = useState<number | null>(null); const n = images.length;
  useEffect(() => {
    if (cur === null) return;
    const k = (e: KeyboardEvent) => { if (e.key === "Escape") setCur(null); if (e.key === "ArrowLeft") setCur((c) => ((c ?? 0) - 1 + n) % n); if (e.key === "ArrowRight") setCur((c) => ((c ?? 0) + 1) % n); };
    addEventListener("keydown", k); return () => removeEventListener("keydown", k);
  }, [cur, n]);
  return (<>
    <div className="gal">{images.map((g, i) => <button key={g.src} onClick={() => setCur(i)} aria-label={`Open photo: ${g.alt}`}><img loading="lazy" src={g.src} alt={g.alt} /></button>)}</div>
    {cur !== null && (<div id="lb" className="o" role="dialog" aria-modal="true" aria-label="Photo viewer" onClick={(e) => e.target === e.currentTarget && setCur(null)}>
      <button autoFocus style={{ top: 16, right: 16 }} aria-label="Close" onClick={() => setCur(null)}>✕</button>
      <button style={{ left: 14 }} aria-label="Previous" onClick={() => setCur((cur - 1 + n) % n)}>‹</button>
      <img src={images[cur].src} alt={images[cur].alt} />
      <button style={{ right: 14 }} aria-label="Next" onClick={() => setCur((cur + 1) % n)}>›</button></div>)}
  </>);
}

export default function SiteClient({ settings: s, menu, gallery }: { settings: Settings; menu: MenuCat[]; gallery: GalleryImg[] }) {
  const [open, setOpen] = useState(false); const dlg = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    const io = new IntersectionObserver((es) => es.forEach((e) => { if (e.isIntersecting) { e.target.classList.add("v"); io.unobserve(e.target); } }), { threshold: 0.12 });
    document.querySelectorAll(".rv").forEach((el) => io.observe(el)); return () => io.disconnect();
  }, []);
  const words = s.hero_headline.split(" "); const last = words.pop();
  const mapsHref = MAPS, tel = `tel:${s.phone_tel}`;
  return (<>
    <div className="bar">OPEN 24 HOURS · FAMILY DINING · NH-33, ULDA</div>
    <header><div className="in"><a href="#home" className="logo" aria-label="Haveli Dhaba home"><span className="gold">♜</span><span>Haveli <b>Dhaba</b></span></a>
      <nav className={open ? "o" : ""} aria-label="Main" onClick={(e) => (e.target as HTMLElement).tagName === "A" && setOpen(false)}><ul>{NAV.map(([h, l]) => <li key={h}><a href={h}>{l}</a></li>)}</ul></nav>
      <a className="btn p hdcta" href={mapsHref} target="_blank" rel="noopener">Get Directions</a>
      <button className="mb" aria-label="Open menu" aria-expanded={open} onClick={() => setOpen(!open)}>☰</button></div></header>
    <main id="home">
      <div className="hero"><div className="w"><span className="lab">Haveli Dhaba · Ulda, Jharkhand</span><h1>{words.join(" ")} <em>{last}</em></h1><p>{s.hero_text}</p>
        <div className="row"><a className="btn p" href={mapsHref} target="_blank" rel="noopener">Get Directions</a><button className="btn s" type="button" onClick={() => dlg.current?.showModal()}>Book a Table</button><a className="btn s" href="#menu">Explore Our Menu</a><a className="btn s" href={tel}>Call Now</a></div>
        <div className="chips"><span className="chip">★ {s.rating} on Google</span><span className="chip">{s.hours}</span><span className="chip">₹200–₹400 per person</span></div></div></div>
      <section><div className="w rv"><span className="lab">At a glance</span><h2>Everything for a good stop</h2><div className="hl">
        {[["🕛", "Open 24 Hours"], ["👨‍👩‍👧", "Family-Friendly Dining"], ["🔥", "Tandoori Specialities"], ["🪑", "Spacious Seating"], ["🌿", "Outdoor Seating"], ["🛝", "Children's Play Area"]].map(([i, t]) => <div key={t}><span>{i}</span>{t}</div>)}</div></div></section>
      <section id="about"><div className="w two"><div className="stack rv"><div className="ph"><img loading="lazy" src="/images/photo-6.jpg" alt="Haveli Dhaba entrance at night with lit steps and potted palms" /></div><div className="ph"><img loading="lazy" src="/images/photo-4.jpg" alt="Illuminated Haveli Dhaba signboard at night" /></div></div>
        <div className="rv"><span className="lab">About Haveli Dhaba</span><h2>Good food, warm <span className="gold">hospitality</span></h2><p className="l">At Haveli Dhaba, good food and warm hospitality come together. Whether you&apos;re stopping along the highway or enjoying a meal with family, we aim to make every visit welcoming and memorable.</p><br /><a className="btn s" href="#family">See the family area</a></div></div></section>
      <section id="menu"><div className="w"><span className="lab">Our Menu</span><h2>Explore the <span className="gold">Full Menu</span></h2><p className="l">Dish names from our printed menu. Prices are shown only once confirmed.</p><Menu menu={menu} /><p className="note">Menu is for browsing only. Please ask our staff about availability.</p></div></section>
      <section><div className="w two"><div className="rv"><span className="lab">Food Experience</span><h2>Indian, veg, non-veg &amp; <span className="gold">tandoori</span></h2><p className="l">From dal and paneer to chicken, mutton, biryani, dosa and Chinese, browse the menu above to see what&apos;s on offer.</p></div><div className="ph rv"><img loading="lazy" src="/images/photo-7.jpg" alt="Haveli Dhaba frontage glowing at night" /></div></div></section>
      <section id="family" style={{ background: "var(--bg2)" }}><div className="w"><span className="lab">Family &amp; Kids</span><h2>A Place for the <span className="gold">Whole Family</span></h2><p className="l">Enjoy your time together in a welcoming dining environment with outdoor seating and a dedicated play area shown in our photos.</p>
        <div className="kids rv"><div className="ph"><img loading="lazy" src="/images/photo-1.jpg" alt="Children playing near swings and a slide with benches" /></div><div className="ph"><img loading="lazy" src="/images/photo-2.jpg" alt="Child at the top of a yellow slide" /></div><div className="ph"><img loading="lazy" src="/images/photo-3.jpg" alt="Outdoor seating beside the play area" /></div></div></div></section>
      <section id="gallery"><div className="w"><span className="lab">Gallery</span><h2>Moments at <span className="gold">Haveli Dhaba</span></h2><Gallery images={gallery} /></div></section>
      <section><div className="w"><div className="rate rv"><div><big>{s.rating}</big><div className="gold">★★★★☆</div></div><div><h3>Approximately {Number(s.review_count).toLocaleString("en-IN")} Google reviews</h3><p className="l">Rating and review count as provided by the restaurant owner.</p></div></div></div></section>
      <section id="venue"><div className="w"><div className="vn rv"><span className="lab">Book Our Venue</span><h2>Celebrate Your Special Moments at <span className="gold">Haveli Dhaba</span></h2><p className="l">Planning a family celebration, birthday, wedding function, corporate gathering, or private event? Contact Haveli Dhaba to enquire about booking the venue.</p>
        <div className="notice">Venue bookings are subject to availability and management approval. Please contact us to discuss your requirements.</div><BookingForm kind="venue" phoneDisplay={s.phone} phoneTel={s.phone_tel} /></div></div></section>
      <section id="contact"><div className="w loc"><div className="rv"><span className="lab">Visit Us</span><h2>Find <span className="gold">Haveli Dhaba</span></h2><p className="l">{s.address}</p><br /><p><b>Phone:</b> <a className="gold" href={tel}>{s.phone}</a><br /><b>Hours:</b> {s.hours}</p><br />
        <div className="row"><a className="btn p" href={tel}>Call Now</a><a className="btn s" href={mapsHref} target="_blank" rel="noopener">Get Directions</a></div></div>
        <iframe loading="lazy" title="Map to Haveli Dhaba" src="https://maps.google.com/maps?q=Haveli+Dhaba+Ulda+Jharkhand+832304&output=embed" /></div></section>
      <section><div className="w"><div className="ig rv"><span className="lab">Instagram</span><h2>Follow @haveli.dhaba</h2><p className="l">See what&apos;s happening at Haveli Dhaba.</p><a className="btn p" href={s.instagram} target="_blank" rel="noopener">Follow on Instagram</a></div></div></section>
    </main>
    <footer><div className="w"><div className="fg"><div><div className="logo"><span className="gold">♜</span>Haveli <b>Dhaba</b></div><p style={{ marginTop: 12 }}>Family-friendly Indian highway dhaba specialising in tandoori dishes. Open 24 hours.</p></div>
      <div><h4>Explore</h4><ul><li><a href="#about">About</a></li><li><a href="#menu">Menu</a></li><li><a href="#gallery">Gallery</a></li><li><a href="#family">Family &amp; Kids</a></li><li><a href="#venue">Book Our Venue</a></li><li><a href={s.instagram} target="_blank" rel="noopener">Instagram</a></li></ul></div>
      <div><h4>Visit</h4><p>{s.address}<br /><a href={tel}>{s.phone}</a> · {s.hours}</p><br /><a className="btn p" href={mapsHref} target="_blank" rel="noopener">Get Directions</a></div></div>
      <p style={{ marginTop: 34, textAlign: "center" }}>© {new Date().getFullYear()} Haveli Dhaba. All rights reserved.</p></div></footer>
    <dialog ref={dlg} aria-labelledby="tt"><button className="x" type="button" aria-label="Close" onClick={() => dlg.current?.close()}>✕</button><span className="lab">Book a Table</span><h3 id="tt" style={{ fontSize: "1.8rem", margin: "6px 0 16px" }}>Request a table</h3><BookingForm kind="table" phoneDisplay={s.phone} phoneTel={s.phone_tel} /></dialog>
  </>);
}
